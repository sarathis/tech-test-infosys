import * as TYPES from '../types';

const onSavePinSuccess = payload => {
    return {
        payload,
        type: TYPES.PIN_SAVE,
    };
};
export const savePin = (pin) => {
    return (dispatch) => {

        dispatch(onSavePinSuccess(pin));
    }

}
const onDeletePinSuccess = payload => {
    return {
        payload,
        type: TYPES.PIN_DELETE,
    };
};
export const deleteSavedPin = (savedPins, pin) => {
    const index = savedPins.indexOf(pin);
    let pins = [];
    if (index > -1) {
        savedPins.splice(index, 1);
        pins = [...savedPins];
    }
    return (dispatch) => {
        dispatch(onDeletePinSuccess(pins ? pins : savedPins));
    }

}


