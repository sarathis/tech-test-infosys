import { combineReducers } from 'redux'
import pinGenerateReducer from './PinGenerateReducer';

const rootReducer = combineReducers({
    pinGenerateReducer
})

export default rootReducer;