import { PIN_SAVE, PIN_DELETE } from "../types";
const initialState = {
    pins: []
}

export default function pinGenerate(state = initialState, action) {
    switch (action.type) {
        case PIN_SAVE:
            return {
                ...state,
                pins: [...state.pins, action.payload]
            };
        case PIN_DELETE:
            return {
                ...state,
                pins: action.payload
            };

        default:
            return {
                ...state
            };
    }
};