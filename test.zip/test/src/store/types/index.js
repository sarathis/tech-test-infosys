export const PIN_SAVE = "PIN_SAVE";
export const PIN_DELETE = "PIN_DELETE";
