import React, { lazy, Suspense } from 'react';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react'
import { persistor, store } from './store';

import './App.css';

function App() {
  const CodeGenerate = lazy(() => import('./modules/codegenerate/containers/CodeGenerate'));
  return (
    <div className="App">

      <Suspense
        fallback={<div className="supsense-loading">
          Loading....
    </div>}>
        <div className="main-content">
          <Provider store={store}>
            <PersistGate loading={null} persistor={persistor}>
              <CodeGenerate />
            </PersistGate>
          </Provider>
        </div>
      </Suspense>

    </div>
  );
}

export default App;
