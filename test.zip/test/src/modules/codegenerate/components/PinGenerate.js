import React from 'react';
import PinInputBox from '../../../controls/PinInputBox';

const PinGenerate = (props) => {
    return (
        <div className="inner-content">
            <PinInputBox pin={props.pin} />
            <div className="button-container">
                <button className="generate" onClick={props.onGenerateClick}>Generate</button>
                <button onClick={(event) => props.onSaveClick(props.pin, event)}
                    disabled={!props.saveEnabled}>
                    Save
                </button>
            </div>
        </div>
    )
}
export default PinGenerate;