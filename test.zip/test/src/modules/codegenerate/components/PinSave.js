import React from 'react';
import { Input } from 'antd';
import PinInputBox from '../../../controls/PinInputBox';

const PinSave = (props) => {
    return (
        <div className="pins-list">
            {props.savedPins && props.savedPins.length > 0 ? props.savedPins.map((pin, index) => {
                if (pin && pin.length > 0) {
                    return (
                        <div key={pin[0] + index} className="saved-pin-item">
                            <Input className="name-input" placeholder="Name" />
                            <PinInputBox pin={pin} />
                            <button className="delete-button" onClick={(event) => props.onDeleteClick(pin, event)}>Delete</button>
                        </div>
                    )
                }
                else {
                    return 'No saved pins'
                }
            }) : ' No saved pins'}
        </div>
    )
}
export default PinSave;