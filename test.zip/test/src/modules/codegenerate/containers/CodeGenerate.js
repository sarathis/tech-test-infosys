import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Tabs } from 'antd';
import PinGenerate from '../components/PinGenerate';
import PinSave from '../components/PinSave';
import { savePin, deleteSavedPin } from '../../../store/actions/PinGenerateAction';
import 'antd/dist/antd.css';
import '../styles/index.scss';

const { TabPane } = Tabs;

// Pin Generater and Saved pins lookup tab component
class CodeGenerate extends Component {
    constructor(props) {
        super(props);
        this.state = { pins: null, enableSave: false, generatedPin: null };
    }

    // Generates unique 5 pins
    pinGenerate = () => {

        let generatedPin = [this.getRandomNumber(),
            this.getRandomNumber(),
            this.getRandomNumber(),
            this.getRandomNumber(),
            this.getRandomNumber()]
        this.setState({ enableSave: true, generatedPin: generatedPin });
    }

    //Gets unique random number to pass as pin
    //returns:unique random number
    getRandomNumber = () => {
        var ranNum = "";
        do {
            ranNum=Math.floor(1000 + Math.random() * 9000);
        }
        while (this.hasDuplicate(ranNum.toString())&&this.hasNoSequentialNumbers(ranNum.toString()));
        return ranNum;
    }

    //Finds duplicate numbers inside pin
    //pin:the 4 digit pin
    //returns:true id duplicate occurs,false when unique
    hasDuplicate = (pin) =>
    {
        let hasRepeat=false;
        let counts= [...pin].reduce((a, e) => {
             a[e] = a[e] ? a[e] + 1 : 1;
             return a }, {});
             for(let w in counts)
             {
                 if(counts[w]>1)
                 {
                    hasRepeat=true;
                 }           

             }
        return hasRepeat;

    }
    
    //Checks for sequential number in the pin
    //pin:the 4 digits pin
    //returns true when no sequential occurs else false
    hasNoSequentialNumbers = (pin) =>
    {
        let numbers = "0123456789";  
        let numbersRev = "9876543210";
        return numbers.indexOf(String(pin)) === -1 && numbersRev.indexOf(String(pin)) === -1;   

    }

    //Saves generate pins to the redux store
    //pin:genarted pin
    saveGeneratedPin = (pin) => {

        if (pin && pin.length > 0) {
            this.props.savePin(pin);
            this.setState({ generatedPin: null, enableSave: false });
        }
    }

    //Deletes the paticular pin from the redux.
    //pin:pin to be deleted
    deletedSavedPin = (pin) => {
        this.props.deleteSavedPin(this.props.pins, pin);
    }

    //renders UI Components
    render() {
        return (
            <div className="content">
                <Tabs defaultActiveKey="1">
                    <TabPane tab="Generate" key="1">
                        <PinGenerate pin={this.state.generatedPin}
                            saveEnabled={this.state.enableSave}
                            onGenerateClick={this.pinGenerate}
                            onSaveClick={this.saveGeneratedPin} />
                    </TabPane>
                    <TabPane tab="Saved" key="2">
                        <PinSave savedPins={this.props.pins} onDeleteClick={this.deletedSavedPin} />
                    </TabPane>
                </Tabs>
            </div>
        )
    }
}

//maps redux state to component props
//state:redux state
const mapStateToProps = (state) => {
    return {
        pins: state.pinGenerateReducer && state.pinGenerateReducer.pins
    }
}

export default connect(mapStateToProps, { savePin, deleteSavedPin })(CodeGenerate);