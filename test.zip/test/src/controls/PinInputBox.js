import React from 'react';
import { Input } from 'antd';
import './index.scss';

const PinInputBox = (props) => {
    return (
        <div>
            {props.pin ? <div className="inputbox-container">
                {props.pin.map((pin, index) => {
                    return (
                        <Input key={pin + index} className="inputbox"
                            value={pin} contentEditable={false} />
                    )
                })
                }
            </div> :
                <div className="inputbox-container">
                    <Input className="inputbox" />
                    <Input className="inputbox" />
                    <Input className="inputbox" />
                    <Input className="inputbox" />
                    <Input className="inputbox" />
                </div>

            }
        </div>
    )

}
export default PinInputBox;